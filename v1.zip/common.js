class Common {
    endpointHealthContext = {
        namespace: "Alexa.EndpointHealth",
        name: "connectivity",
        value: {
            value: "OK"
        },
        timeOfSample: JSON.stringify(new Date()).replace(/"/gi, ''),
        uncertaintyInMilliseconds: 0
    };
    powerControllerContext = {
        namespace: "Alexa.PowerController",
        name: "powerState",
        value: "",
        timeOfSample: JSON.stringify(new Date()).replace(/"/gi, ''),
        uncertaintyInMilliseconds: 0
    };
    brightnessControllerContext = {
        namespace: "Alexa.BrightnessController",
        name: "brightness",
        value: "",
        timeOfSample: JSON.stringify(new Date()).replace(/"/gi, ''),
        uncertaintyInMilliseconds: 0
    };
    colorControllerContext = {
        namespace: "Alexa.ColorController",
        name: "color",
        value: {
            "hue": 350.5,
            "saturation": 0.7138,
            "brightness": 0.6524
        },
        timeOfSample: JSON.stringify(new Date()).replace(/"/gi, ''),
        uncertaintyInMilliseconds: 0
    };
    hslToHex = function (h, s, l) {
        l /= 100;
        const a = s * Math.min(l, 1 - l) / 100;
        const f = n => {
            const k = (n + h / 30) % 12;
            const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
            return Math.round(255 * color).toString(16).padStart(2, '0');   // convert to Hex and prefix "0" if needed
        };
        return `#${f(0)}${f(8)}${f(4)}`;
    }
}
module.exports = Common;