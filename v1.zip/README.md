# Areana.IoT.Lambda
Areana IoT Smart Home Alexa Skill Lambda function
